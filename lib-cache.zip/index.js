const Cache = require('./src/handler');

/**
 * Exporta o Cache.
 * @returns {Cache} - A classe de Cache
 */
module.exports = Cache;
